import pyodbc
conn = pyodbc.connect(
        r'DRIVER={SQL Server};'
        r'Server=DESKTOP-1U8VTHG\SQLEXPRESS;'
        r'Database=Hospital_Case_Study;'
        r'Trusted_Connection=yes;')

cursor = conn.cursor()
sql = r'SELECT * FROM Fact_fall'

import pandas as pd
Fall = pd.read_sql(sql,conn)
conn.close()

Fall["Critical_Injury"] = Fall['InJuryLevel_Key'].apply(lambda x:1 if x == 3 else 0)

Fall = Fall.drop(['Witness_Flag_key','PatientUnitCase_key','Fall_SKey','Cohorent_Flag_Key','InJuryLevel_Key','Nurse_Key','TimeofFall','Date_key', 'Time_key', 'Fall'],axis=1)


from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix,classification_report
X_train, X_test, y_train, y_test = train_test_split(Fall.drop('Critical_Injury',axis=1), Fall['Critical_Injury'], test_size=0.30,random_state=101)
from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier()
gb.fit(X_train, y_train)
gb_pred = gb.predict(X_test)
print(confusion_matrix(y_test,gb_pred))
print(classification_report(y_test,gb_pred))

#             precision    recall  f1-score   support
#
#          0       0.94      1.00      0.97      1140
#          1       1.00      0.63      0.77       199
#
#avg / total       0.95      0.94      0.94      1339
