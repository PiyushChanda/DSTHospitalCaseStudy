# -*- coding: utf-8 -*-


# Following Features are found to be important in predicting the likelyhood of a major injury
# ['Location_Key', 'PatientActivity_key', 'Latest WHeFRA score',
#  'Functional_Key', 'Medication_Key1', 'Medication_Key2',
#  'Medication_Key3', 'Medication_Key4', 'Medication_Key5', 'History_Fall',
#  'NurseActivity_Key', 'Shift_key', 'overlap', 'WHeFRAscore_key',
#  'MedicationNos', 'NurseHourseonShift', 'Critical_Injury']

import pandas as pd

Fall = pd.read_excel("Microsoft_Excel_Worksheet.xlsx",sheet_name="Fact_fall")

Fall["Critical_Injury"] = Fall['InJuryLevel_Key'].apply(lambda x:1 if x == 3 else 0)

Fall = Fall.drop(['Witness_Flag_key','PatientUnitCase_key','Fall_SKey','Cohorent_Flag_Key','InJuryLevel_Key','Nurse_Key','TimeofFall','Date_key', 'Time_key', 'Fall'],axis=1)


from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix,classification_report
X_train, X_test, y_train, y_test = train_test_split(Fall.drop('Critical_Injury',axis=1), Fall['Critical_Injury'], test_size=0.30,random_state=101)
from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier()
gb.fit(X_train, y_train)
gb_pred = gb.predict(X_test)
print(confusion_matrix(y_test,gb_pred))
print(classification_report(y_test,gb_pred))

#             precision    recall  f1-score   support
#
#          0       0.94      1.00      0.97      1140
#          1       1.00      0.63      0.77       199
#
#avg / total       0.95      0.94      0.94      1339
